// Youngest Fashion - public browser configuration.
// Publishable keys are designed for browser use. Never place a service_role/secret key here.
window.YF_CONFIG = {
  supabaseUrl: "https://rsxocrzrcksrvlllqjcb.supabase.co",
  supabaseKey: "sb_publishable_-100a8SpxJzx5O8viODKNg_UPRU2QrZ",
  currency: "GHS"
};
