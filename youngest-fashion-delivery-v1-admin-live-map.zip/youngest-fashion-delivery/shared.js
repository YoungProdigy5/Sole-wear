(() => {
  const cfg = window.YF_CONFIG;
  if (!cfg || !cfg.supabaseUrl || !cfg.supabaseKey) throw new Error("Missing Supabase config.");
  window.db = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey);
  window.money = n => new Intl.NumberFormat("en-GH",{style:"currency",currency:"GHS",maximumFractionDigits:2}).format(Number(n||0));
  window.el = id => document.getElementById(id);
  window.escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  window.showMessage = (id, msg, type="") => { const node=el(id); if(!node)return; node.textContent=msg; node.className="status "+type; node.classList.remove("hidden"); };
  window.requireSession = async () => {
    const {data,error}=await db.auth.getSession();
    if(error) throw error;
    return data.session;
  };
  window.signInForm = async (email,password) => {
    const {data,error}=await db.auth.signInWithPassword({email,password});
    if(error) throw error;
    return data.user;
  };
  window.signOut = async () => { await db.auth.signOut(); location.reload(); };
  window.initMap = (id, center=[5.6037,-0.1870], zoom=12) => {
    const map=L.map(id,{scrollWheelZoom:false}).setView(center,zoom);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"&copy; OpenStreetMap contributors"}).addTo(map);
    return map;
  };
})();
