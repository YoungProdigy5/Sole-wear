-- Youngest Fashion: rider identities, assignments and live GPS.
-- This additive migration was applied to Supabase project rsxocrzrcksrvlllqjcb on 2026-11-03.
create table if not exists public.delivery_riders (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 80),
  phone text check (phone is null or char_length(phone) <= 30),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.delivery_assignments (
  order_id bigint primary key references public.orders(id) on delete cascade,
  rider_id uuid not null references public.delivery_riders(user_id) on delete restrict,
  assigned_by uuid not null references auth.users(id),
  assigned_at timestamptz not null default now()
);
create table if not exists public.rider_locations (
  rider_id uuid not null references public.delivery_riders(user_id) on delete cascade,
  order_id bigint not null references public.orders(id) on delete cascade,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  accuracy_m double precision check (accuracy_m is null or accuracy_m between 0 and 100000),
  heading double precision check (heading is null or heading between 0 and 360),
  speed_mps double precision check (speed_mps is null or speed_mps between 0 and 150),
  updated_at timestamptz not null default now(),
  is_sharing boolean not null default true,
  primary key (rider_id, order_id)
);
create index if not exists delivery_assignments_rider_idx on public.delivery_assignments(rider_id);
create index if not exists delivery_assignments_assigned_by_idx on public.delivery_assignments(assigned_by);
create index if not exists rider_locations_order_idx on public.rider_locations(order_id, updated_at desc);
alter table public.delivery_riders enable row level security;
alter table public.delivery_assignments enable row level security;
alter table public.rider_locations enable row level security;
grant select on public.delivery_riders to authenticated;
grant select, insert, update, delete on public.delivery_assignments to authenticated;
grant select, insert, update on public.rider_locations to authenticated;

create policy "read permitted rider profiles" on public.delivery_riders for select to authenticated
using (public.is_admin() or user_id=(select auth.uid()) or exists (
  select 1 from public.delivery_assignments a join public.orders o on o.id=a.order_id
  where a.rider_id=delivery_riders.user_id and o.user_id=(select auth.uid()) and o.status='on the way'));
create policy "admin inserts delivery riders" on public.delivery_riders for insert to authenticated with check (public.is_admin());
create policy "admin updates delivery riders" on public.delivery_riders for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin deletes delivery riders" on public.delivery_riders for delete to authenticated using (public.is_admin());

create policy "read permitted delivery assignments" on public.delivery_assignments for select to authenticated
using (public.is_admin() or rider_id=(select auth.uid()) or exists (
  select 1 from public.orders o where o.id=delivery_assignments.order_id and o.user_id=(select auth.uid())));
create policy "admin inserts delivery assignments" on public.delivery_assignments for insert to authenticated with check (public.is_admin());
create policy "admin updates delivery assignments" on public.delivery_assignments for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admin deletes delivery assignments" on public.delivery_assignments for delete to authenticated using (public.is_admin());

create policy "read permitted rider locations" on public.rider_locations for select to authenticated
using (public.is_admin() or rider_id=(select auth.uid()) or exists (
  select 1 from public.delivery_assignments a join public.orders o on o.id=a.order_id
  where a.order_id=rider_locations.order_id and a.rider_id=rider_locations.rider_id
    and o.user_id=(select auth.uid()) and o.status='on the way' and rider_locations.is_sharing=true));
create policy "active riders publish assigned locations" on public.rider_locations for insert to authenticated
with check (rider_id=(select auth.uid())
  and exists(select 1 from public.delivery_riders r where r.user_id=(select auth.uid()) and r.is_active)
  and exists(select 1 from public.delivery_assignments a join public.orders o on o.id=a.order_id
    where a.order_id=rider_locations.order_id and a.rider_id=(select auth.uid()) and o.status in ('confirmed','on the way')));
create policy "active riders update assigned locations" on public.rider_locations for update to authenticated
using (rider_id=(select auth.uid()) and exists(select 1 from public.delivery_riders r where r.user_id=(select auth.uid()) and r.is_active))
with check (rider_id=(select auth.uid()) and exists(select 1 from public.delivery_assignments a join public.orders o on o.id=a.order_id
  where a.order_id=rider_locations.order_id and a.rider_id=(select auth.uid()) and o.status in ('confirmed','on the way')));

create schema if not exists private;
revoke all on schema private from public, anon;
grant usage on schema private to authenticated;
create or replace function private.is_assigned_delivery_rider(p_order bigint) returns boolean
language sql stable security definer set search_path=public,auth,pg_temp as $$
  select auth.uid() is not null and exists(select 1 from public.delivery_assignments a
  join public.delivery_riders r on r.user_id=a.rider_id where a.order_id=p_order and a.rider_id=auth.uid() and r.is_active);
$$;
revoke all on function private.is_assigned_delivery_rider(bigint) from public,anon;
grant execute on function private.is_assigned_delivery_rider(bigint) to authenticated;
drop policy if exists "own orders" on public.orders;
drop policy if exists "assigned riders read assigned orders" on public.orders;
create policy "customers admins and assigned riders read orders" on public.orders for select to authenticated
using (user_id=(select auth.uid()) or public.is_admin() or private.is_assigned_delivery_rider(id));

create or replace function public.register_delivery_rider(p_email text,p_display_name text,p_phone text default null)
returns uuid language plpgsql security definer set search_path=public,auth,pg_temp as $$
declare v_user_id uuid; v_email text:=lower(trim(coalesce(p_email,'')));
begin
 if auth.uid() is null or not public.is_admin() then raise exception 'Only an authenticated administrator can register riders'; end if;
 if v_email='' or position('@' in v_email)<2 then raise exception 'Enter a valid rider email address'; end if;
 if trim(coalesce(p_display_name,''))='' then raise exception 'Rider name is required'; end if;
 select id into v_user_id from auth.users where lower(email)=v_email limit 1;
 if v_user_id is null then raise exception 'The rider must create a Youngest Fashion account before being registered'; end if;
 insert into public.delivery_riders(user_id,display_name,phone,is_active)
 values(v_user_id,left(trim(p_display_name),80),nullif(trim(p_phone),''),true)
 on conflict(user_id) do update set display_name=excluded.display_name,phone=excluded.phone,is_active=true;
 return v_user_id;
end; $$;
create or replace function public.set_delivery_status(p_order bigint,p_status text)
returns void language plpgsql security definer set search_path=public,auth,pg_temp as $$
declare v_current text;
begin
 if auth.uid() is null then raise exception 'Please log in first'; end if;
 if p_status not in ('on the way','delivered') then raise exception 'Invalid delivery status'; end if;
 if not public.is_admin() and not exists(select 1 from public.delivery_assignments a join public.delivery_riders r on r.user_id=a.rider_id
   where a.order_id=p_order and a.rider_id=auth.uid() and r.is_active) then raise exception 'You are not assigned to this delivery'; end if;
 select status into v_current from public.orders where id=p_order for update;
 if not found then raise exception 'Order not found'; end if;
 if p_status='on the way' and v_current<>'confirmed' then raise exception 'Only confirmed orders can be marked on the way'; end if;
 if p_status='delivered' and v_current<>'on the way' then raise exception 'Only orders on the way can be marked delivered'; end if;
 update public.orders set status=p_status where id=p_order;
end; $$;
revoke all on function public.register_delivery_rider(text,text,text) from public,anon;
grant execute on function public.register_delivery_rider(text,text,text) to authenticated;
revoke all on function public.set_delivery_status(bigint,text) from public,anon;
grant execute on function public.set_delivery_status(bigint,text) to authenticated;

do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='delivery_assignments') then alter publication supabase_realtime add table public.delivery_assignments; end if;
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='rider_locations') then alter publication supabase_realtime add table public.rider_locations; end if;
end $$;
