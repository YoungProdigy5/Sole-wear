# Youngest Fashion — Delivery Tracking v1

This is an additive rider-tracking layer for the existing Youngest Fashion GitHub Pages + Supabase project. It does not replace the existing storefront or its customer GPS checkout.

## What's included
- `rider.html` / `rider.js`: rider login, assigned order list, navigation, start/stop GPS sharing, status updates.
- `dispatch.html` / `dispatch.js`: admin-only rider registration and order assignment.
- `track.html` / `track.js`: customer login and live rider map for orders marked `on the way`.
- `config.js`: current Supabase project URL and browser-safe publishable key.
- `delivery.css`, `shared.js`: shared layout and helpers.
- `database/001_delivery_riders.sql`: schema/policy reference for version control. The matching database migration has already been applied to the connected Supabase project.

## Existing project reused
- Supabase project: `YOUNGEST FASHION` (`rsxocrzrcksrvlllqjcb`)
- Existing GitHub repository: `YoungProdigy5/Sole-wear`
- Existing product, customer, order, Ghana address, checkout GPS, delivery-zone, and admin systems are preserved.

## Deploy to the existing GitHub Pages repository
1. Download and extract this ZIP.
2. Open the existing `Sole-wear` repository.
3. Upload these new files into the repository root, keeping the `database` folder.
4. Do not overwrite `index.html`, `ops.js`, `delivery-locator.js`, `live-map.js`, `precise-location.js`, or other existing files.
5. Commit the new files to `main`. GitHub Pages will publish:
   - `/rider.html`
   - `/dispatch.html`
   - `/track.html`

## First-time setup
1. Sign in to the existing shop as the administrator.
2. Create a normal customer account for each delivery rider (use the existing storefront sign-up).
3. Open `/dispatch.html` while signed in as an administrator.
4. Register each rider using the same email address used for their account.
5. Assign a confirmed order to that rider.
6. Give the rider `/rider.html`. They sign in with their account, open the assigned order, and tap **Start live GPS**.
7. Give customers `/track.html`. They sign in using the account that placed the order. The rider marker appears when the order is `on the way` and GPS sharing is active.

## Important behaviour and limitations
- Browser GPS requires HTTPS and explicit permission.
- Rider GPS is shared only while the rider has the rider page open and has pressed Start live GPS. Browser background limits, battery saver, closing the tab, or loss of connectivity can pause updates.
- This is not yet a native background-tracking app.
- Maps use OpenStreetMap tiles and Leaflet; routes/navigation open Google Maps.
- Payment collection remains as currently implemented by the existing store.
- Do not put a Supabase service-role/secret key in browser files. The included key is a publishable key and database access is protected by RLS.
- Customer map access is limited to the assigned rider on that customer's active `on the way` order.

## Manual smoke-test checklist
- [ ] Customer account can sign in at `track.html`.
- [ ] Rider account cannot access `dispatch.html`.
- [ ] Admin can register an existing customer account as a rider.
- [ ] Admin can assign a confirmed order.
- [ ] Rider sees only assigned orders.
- [ ] Rider can start GPS sharing and see their own map pin.
- [ ] Rider can change `confirmed` → `on the way` → `delivered`.
- [ ] Customer can see the assigned rider only while the order is `on the way`.
- [ ] Stopping GPS changes the share state to off.
- [ ] An unassigned rider cannot update another rider's order status.

## Security note
The two public-schema RPC functions are `SECURITY DEFINER` because the rider workflow needs to register Auth users and update only the delivery status while the existing orders table is admin-controlled. Both functions check the signed-in user and administrator/assignment authorization before changing data. Supabase's security advisor also reports other pre-existing `SECURITY DEFINER` functions in this project and disabled leaked-password protection; review those separately before a public launch.
