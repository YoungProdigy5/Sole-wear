let customer=null,customerOrders=[],selectedOrder=null,trackMap=null,riderPin=null,customerPin=null,trackChannel=null,trackTimer=null;
async function bootTrack(){
  const session=await requireSession();if(!session){el("loginPanel").classList.remove("hidden");return;}
  customer=session.user;el("loginPanel").classList.add("hidden");el("appPanel").classList.remove("hidden");
  trackMap=initMap("trackMap");await loadCustomerOrders();
  trackChannel=db.channel("customer-rider-location").on("postgres_changes",{event:"*",schema:"public",table:"rider_locations"},payload=>{if(selectedOrder&&Number(payload.new?.order_id)===selectedOrder.id)refreshSelected();}).on("postgres_changes",{event:"UPDATE",schema:"public",table:"orders",filter:`user_id=eq.${customer.id}`},loadCustomerOrders).subscribe();
  trackTimer=setInterval(()=>{if(selectedOrder)refreshSelected();},15000);
}
async function loadCustomerOrders(){
  const {data,error}=await db.from("orders").select("id,status,total,address,lat,lng,created_at").eq("user_id",customer.id).in("status",["confirmed","on the way"]).order("created_at",{ascending:false});
  if(error)throw error;customerOrders=data||[];
  el("orders").innerHTML=customerOrders.length?customerOrders.map(o=>`<button class="item" style="text-align:left;color:inherit" data-track="${o.id}"><div class="itemtop"><strong>Order #${1000+o.id}</strong><span class="pill">${escapeHtml(o.status)}</span></div><div>${escapeHtml(o.address||"Delivery address")}</div><div class="small">${money(o.total)} · ${new Date(o.created_at).toLocaleString()}</div></button>`).join(""):'<div class="item small">You have no active deliveries right now.</div>';
  if(selectedOrder){selectedOrder=customerOrders.find(o=>o.id===selectedOrder.id)||null;if(selectedOrder)await refreshSelected();}
}
async function refreshSelected(){
  if(!selectedOrder)return;
  const {data:a,error:ae}=await db.from("delivery_assignments").select("rider_id").eq("order_id",selectedOrder.id).maybeSingle();
  if(ae)throw ae;if(!a){showMessage("trackMsg","Your order has not been assigned to a rider yet.","warn");return;}
  const {data:r,error:re}=await db.from("delivery_riders").select("display_name,phone").eq("user_id",a.rider_id).maybeSingle();
  if(re)throw re;
  const {data:l,error:le}=await db.from("rider_locations").select("lat,lng,accuracy_m,updated_at,is_sharing").eq("order_id",selectedOrder.id).eq("rider_id",a.rider_id).maybeSingle();
  if(le)throw le;
  if(selectedOrder.lat!=null&&selectedOrder.lng!=null){
    if(customerPin)customerPin.remove();customerPin=L.marker([selectedOrder.lat,selectedOrder.lng]).addTo(trackMap).bindPopup("Your delivery location").openPopup();
  }
  if(!l){showMessage("trackMsg",`Assigned to ${r?.display_name||"your rider"}. Waiting for the rider to share GPS.`,"warn");return;}
  const age=Math.max(0,Math.round((Date.now()-new Date(l.updated_at).getTime())/1000));
  if(riderPin)riderPin.remove();riderPin=L.circleMarker([l.lat,l.lng],{radius:10,color:"#fff",weight:2,fillColor:"#c6ff3d",fillOpacity:1}).addTo(trackMap).bindPopup(`Rider: ${escapeHtml(r?.display_name||"Delivery rider")}`);
  const bounds=[[l.lat,l.lng]];if(selectedOrder.lat!=null&&selectedOrder.lng!=null)bounds.push([selectedOrder.lat,selectedOrder.lng]);trackMap.fitBounds(bounds,{padding:[35,35],maxZoom:15});
  const freshness=age<45?"LIVE":`last update ${age}s ago`;
  showMessage("trackMsg",`${freshness} · Rider: ${r?.display_name||"Delivery rider"} · GPS accuracy ±${Math.round(l.accuracy_m||0)} m${l.is_sharing?"":" · rider paused sharing"}`,age<45&&l.is_sharing?"good":"warn");
}
el("loginForm").addEventListener("submit",async e=>{e.preventDefault();try{await signInForm(el("email").value.trim(),el("password").value);await bootTrack();}catch(err){showMessage("loginMsg",err.message,"bad");}});
el("orders").addEventListener("click",async e=>{const b=e.target.closest("[data-track]");if(!b)return;selectedOrder=customerOrders.find(o=>o.id===Number(b.dataset.track));await refreshSelected();});
window.addEventListener("beforeunload",()=>{if(trackTimer)clearInterval(trackTimer);if(trackChannel)db.removeChannel(trackChannel);});
bootTrack().catch(e=>showMessage("loginMsg",e.message,"bad"));
