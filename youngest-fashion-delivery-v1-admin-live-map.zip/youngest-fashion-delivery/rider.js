let currentUser=null, riderProfile=null, assigned=[], orders=[], riderMap=null, meMarker=null, orderLayer=null, watchId=null, lastSent=0, lastPoint=null, liveChannel=null;
const activeStatuses=["confirmed","on the way"];
async function boot(){
  const session=await requireSession();
  if(!session){el("loginPanel").classList.remove("hidden");return;}
  currentUser=session.user;
  const {data:profile,error}=await db.from("delivery_riders").select("*").eq("user_id",currentUser.id).maybeSingle();
  if(error) throw error;
  if(!profile||!profile.is_active){showMessage("loginMsg","This account is not registered as an active Youngest Fashion rider. Ask the administrator to add it.","bad");await db.auth.signOut();el("loginPanel").classList.remove("hidden");return;}
  riderProfile=profile;el("loginPanel").classList.add("hidden");el("appPanel").classList.remove("hidden");
  riderMap=initMap("riderMap");orderLayer=L.layerGroup().addTo(riderMap);await loadAssignments();
  liveChannel=db.channel("rider-assignment-feed").on("postgres_changes",{event:"*",schema:"public",table:"delivery_assignments",filter:`rider_id=eq.${currentUser.id}`},loadAssignments).subscribe();
}
async function loadAssignments(){
  const {data:a,error}=await db.from("delivery_assignments").select("order_id,assigned_at").eq("rider_id",currentUser.id).order("assigned_at",{ascending:false});
  if(error) throw error;
  assigned=a||[];const ids=assigned.map(x=>x.order_id);
  if(!ids.length) orders=[];
  else {const {data:o,error:oe}=await db.from("orders").select("id,status,total,address,phone,lat,lng,created_at,note,items").in("id",ids).order("created_at",{ascending:false});if(oe)throw oe;orders=o||[];}
  el("assignedCount").textContent=orders.filter(o=>activeStatuses.includes(o.status)).length;
  renderOrders();renderPins();
}
function renderOrders(){
  const box=el("orders");
  if(!orders.length){box.innerHTML='<div class="item small">No deliveries assigned yet.</div>';return;}
  box.innerHTML=orders.map(o=>{
    const canStart=o.status==="confirmed",canFinish=o.status==="on the way";
    return `<article class="item"><div class="itemtop"><strong>Order #${1000+o.id}</strong><span class="pill">${escapeHtml(o.status)}</span></div>
      <div>${escapeHtml(o.address||"No address supplied")}</div>
      <div class="small">Customer: ${escapeHtml(o.phone||"No phone")} · Total: ${money(o.total)}</div>
      ${o.note?`<div class="small">Directions: ${escapeHtml(o.note)}</div>`:""}
      <div class="btnrow">${o.phone?`<a class="btn secondary" href="tel:${encodeURIComponent(o.phone)}">Call customer</a>`:""}
      ${o.lat!=null&&o.lng!=null?`<a class="btn ghost" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${o.lat},${o.lng}&travelmode=driving">Navigate</a>`:""}
      ${canStart?`<button class="btn" data-status="${o.id}:on the way">Start delivery</button>`:""}
      ${canFinish?`<button class="btn" data-status="${o.id}:delivered">Mark delivered</button>`:""}</div></article>`;
  }).join("");
}
function renderPins(){
  if(!riderMap)return;const pts=[];orderLayer.clearLayers();
  orders.filter(o=>o.lat!=null&&o.lng!=null&&activeStatuses.includes(o.status)).forEach(o=>{
    L.circleMarker([o.lat,o.lng],{radius:8,color:"#fff",weight:2,fillColor:"#ff4d91",fillOpacity:1}).addTo(orderLayer).bindPopup(`Order #${1000+o.id}<br>${escapeHtml(o.address||"")}`);
    pts.push([o.lat,o.lng]);
  });
  if(pts.length)riderMap.fitBounds(pts,{padding:[25,25],maxZoom:14});
}
async function setDeliveryStatus(id,status){
  const {error}=await db.rpc("set_delivery_status",{p_order:Number(id),p_status:status});
  if(error)throw error;
  await loadAssignments();
}
async function publishPosition(position){
  const c=position.coords, now=Date.now(), point={lat:c.latitude,lng:c.longitude};
  if(now-lastSent<8000 && lastPoint && Math.hypot((point.lat-lastPoint.lat)*111000,(point.lng-lastPoint.lng)*111000*Math.cos(point.lat*Math.PI/180))<20)return;
  const targets=orders.filter(o=>activeStatuses.includes(o.status));
  if(!targets.length){showMessage("gpsMsg","No active assigned deliveries. GPS is not being broadcast.","warn");return;}
  const rows=targets.map(o=>({rider_id:currentUser.id,order_id:o.id,lat:c.latitude,lng:c.longitude,accuracy_m:c.accuracy,heading:c.heading,speed_mps:c.speed,is_sharing:true,updated_at:new Date().toISOString()}));
  const {error}=await db.from("rider_locations").upsert(rows,{onConflict:"rider_id,order_id"});
  if(error){showMessage("gpsMsg","Location update failed: "+error.message,"bad");return;}
  lastSent=now;lastPoint=point;el("trackingState").textContent="ON";
  showMessage("gpsMsg",`Sharing live GPS · accuracy ±${Math.round(c.accuracy)} m · updated ${new Date().toLocaleTimeString()}`,"good");
  if(meMarker)meMarker.setLatLng([c.latitude,c.longitude]);
  else meMarker=L.circleMarker([c.latitude,c.longitude],{radius:9,color:"#fff",weight:2,fillColor:"#c6ff3d",fillOpacity:1}).addTo(riderMap).bindTooltip("You");
  riderMap.panTo([c.latitude,c.longitude]);
}
function startGps(){
  if(!navigator.geolocation){showMessage("gpsMsg","This browser does not support GPS.","bad");return;}
  if(watchId!==null)return;
  showMessage("gpsMsg","Waiting for a precise GPS fix…");
  watchId=navigator.geolocation.watchPosition(p=>publishPosition(p),e=>showMessage("gpsMsg",e.message+" Check browser location permission and use HTTPS.","bad"),{enableHighAccuracy:true,maximumAge:5000,timeout:20000});
  el("startGps").disabled=true;el("stopGps").disabled=false;
}
async function stopGps(){
  if(watchId!==null){navigator.geolocation.clearWatch(watchId);watchId=null;}
  const rows=lastPoint?orders.filter(o=>activeStatuses.includes(o.status)).map(o=>({rider_id:currentUser.id,order_id:o.id,lat:lastPoint.lat,lng:lastPoint.lng,is_sharing:false,updated_at:new Date().toISOString()})):[];
  if(rows.length){const {error}=await db.from("rider_locations").upsert(rows,{onConflict:"rider_id,order_id"});if(error)showMessage("gpsMsg","Stopped locally, but could not update sharing status: "+error.message,"warn");}
  el("trackingState").textContent="OFF";el("startGps").disabled=false;el("stopGps").disabled=true;
  showMessage("gpsMsg","GPS sharing stopped.","warn");
}
el("loginForm").addEventListener("submit",async e=>{e.preventDefault();try{await signInForm(el("email").value.trim(),el("password").value);await boot();}catch(err){showMessage("loginMsg",err.message,"bad");}});
el("orders").addEventListener("click",async e=>{const b=e.target.closest("[data-status]");if(!b)return;const [id,status]=b.dataset.status.split(":");b.disabled=true;try{await setDeliveryStatus(id,status);}catch(err){alert(err.message);b.disabled=false;}});
el("startGps").addEventListener("click",startGps);el("stopGps").addEventListener("click",stopGps);
el("refresh").addEventListener("click",()=>loadAssignments().catch(e=>showMessage("gpsMsg",e.message,"bad")));
window.addEventListener("beforeunload",()=>{if(watchId!==null)navigator.geolocation.clearWatch(watchId);if(liveChannel)db.removeChannel(liveChannel);});
boot().catch(e=>showMessage("loginMsg",e.message,"bad"));
