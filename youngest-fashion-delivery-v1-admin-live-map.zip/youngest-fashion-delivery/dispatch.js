let adminUser=null,riders=[],orders=[],assignments=[];
async function bootDispatch(){
  const session=await requireSession();if(!session){el("loginPanel").classList.remove("hidden");return;}
  adminUser=session.user;
  const {data:p,error}=await db.from("profiles").select("role").eq("id",adminUser.id).single();
  if(error||!p||!["admin","super_admin"].includes(p.role)){await db.auth.signOut();el("loginPanel").classList.remove("hidden");showMessage("loginMsg","This account does not have administrator access.","bad");return;}
  el("loginPanel").classList.add("hidden");el("appPanel").classList.remove("hidden");await loadDispatch();await initDispatchMap();
}
async function loadDispatch(){
  const [rr,oo,aa]=await Promise.all([
    db.from("delivery_riders").select("user_id,display_name,phone,is_active").order("created_at",{ascending:false}),
    db.from("orders").select("id,status,total,address,phone,lat,lng,created_at").in("status",["confirmed","on the way"]).order("created_at",{ascending:false}),
    db.from("delivery_assignments").select("order_id,rider_id,assigned_at")
  ]);
  for(const x of [rr,oo,aa])if(x.error)throw x.error;
  riders=rr.data||[];orders=oo.data||[];assignments=aa.data||[];
  renderRiders();renderOrders();if(dispatchMap)await refreshLiveMap();
}
function renderRiders(){
  el("riders").innerHTML=riders.length?riders.map(r=>`<div class="item"><div class="itemtop"><strong>${escapeHtml(r.display_name)}</strong><span class="pill">${r.is_active?"ACTIVE":"PAUSED"}</span></div><span class="small">${escapeHtml(r.phone||"No phone")} · ${r.user_id.slice(0,8)}…</span></div>`).join(""):'<div class="item small">No riders registered yet.</div>';
}
function renderOrders(){
  el("orders").innerHTML=orders.length?orders.map(o=>{
    const a=assignments.find(x=>x.order_id===o.id),assigned=a&&riders.find(r=>r.user_id===a.rider_id);
    return `<article class="item"><div class="itemtop"><strong>Order #${1000+o.id} · ${money(o.total)}</strong><span class="pill">${escapeHtml(o.status)}</span></div><div>${escapeHtml(o.address||"No address")}</div><div class="small">${escapeHtml(o.phone||"No phone")}</div>
    <div class="field"><label>Assign rider ${assigned?"(currently: "+escapeHtml(assigned.display_name)+")":""}</label><select data-order="${o.id}"><option value="">Choose rider…</option>${riders.filter(r=>r.is_active).map(r=>`<option value="${r.user_id}" ${a?.rider_id===r.user_id?"selected":""}>${escapeHtml(r.display_name)}</option>`).join("")}</select></div>
    <div class="btnrow"><button class="btn" data-assign="${o.id}">Save assignment</button>${a?`<button class="btn secondary" data-unassign="${o.id}">Unassign</button>`:""}</div></article>`;
  }).join(""):'<div class="item small">No confirmed or on-the-way orders waiting for dispatch.</div>';
}
let dispatchMap=null,dispatchLayer=null,adminCoords=null,mapRefreshTimer=null,mapChannel=null,mapFirstFit=true;
function validPoint(lat,lng){return lat!==null&&lng!==null&&Number.isFinite(Number(lat))&&Number.isFinite(Number(lng))&&Math.abs(Number(lat))<=90&&Math.abs(Number(lng))<=180;}
function directionsUrl(lat,lng,origin){
  const dest=`${Number(lat)},${Number(lng)}`;
  return origin?`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin.join(","))}&destination=${encodeURIComponent(dest)}&travelmode=driving`:`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}&travelmode=driving`;
}
function addressDirectionsUrl(address){return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}&travelmode=driving`;}
function ageLabel(updatedAt){
  if(!updatedAt)return "No GPS update";
  const seconds=Math.max(0,Math.round((Date.now()-new Date(updatedAt).getTime())/1000));
  return seconds<45?`LIVE · ${seconds}s ago`:seconds<180?`STALE · ${seconds}s ago`:`OFFLINE · ${Math.floor(seconds/60)}m ago`;
}
async function refreshLiveMap(fit=false){
  if(!dispatchMap)return;
  const active=orders.filter(o=>assignments.some(a=>Number(a.order_id)===Number(o.id)));
  const ids=active.map(o=>o.id);
  const [riderResult,locationResult]=await Promise.all([
    ids.length?db.from("delivery_riders").select("user_id,display_name,phone,is_active"):Promise.resolve({data:[],error:null}),
    ids.length?db.from("rider_locations").select("rider_id,order_id,lat,lng,accuracy_m,heading,speed_mps,updated_at,is_sharing").in("order_id",ids):Promise.resolve({data:[],error:null})
  ]);
  if(riderResult.error)throw riderResult.error;if(locationResult.error)throw locationResult.error;
  const riderRows=riderResult.data||[],locations=locationResult.data||[],bounds=[];
  dispatchLayer.clearLayers();let reporting=0,stale=0;const cards=[];
  for(const order of active){
    const assignment=assignments.find(a=>Number(a.order_id)===Number(order.id));
    const rider=riderRows.find(r=>r.user_id===assignment?.rider_id);
    const loc=locations.find(l=>Number(l.order_id)===Number(order.id)&&l.rider_id===assignment?.rider_id);
    const hasRider=!!(loc&&validPoint(loc.lat,loc.lng));
    const fresh=hasRider&&loc.is_sharing&&Date.now()-new Date(loc.updated_at).getTime()<45000;
    if(fresh)reporting++;else stale++;
    if(hasRider){
      const point=[Number(loc.lat),Number(loc.lng)];bounds.push(point);
      L.circleMarker(point,{radius:9,color:"#ffffff",weight:2,fillColor:"#c6ff3d",fillOpacity:1}).addTo(dispatchLayer)
        .bindPopup(`<b>${escapeHtml(rider?.display_name||"Delivery rider")}</b><br>Order #${1000+order.id}<br>${escapeHtml(ageLabel(loc.updated_at))}<br>GPS ±${Math.round(loc.accuracy_m||0)} m`);
    }
    const hasDestination=validPoint(order.lat,order.lng);
    if(hasDestination){
      const dest=[Number(order.lat),Number(order.lng)];bounds.push(dest);
      L.circleMarker(dest,{radius:8,color:"#ffffff",weight:2,fillColor:"#ff4d91",fillOpacity:1}).addTo(dispatchLayer)
        .bindPopup(`<b>Customer destination</b><br>Order #${1000+order.id}<br>${escapeHtml(order.address||"Address not provided")}`);
    }
    const nav=hasDestination?directionsUrl(order.lat,order.lng,hasRider?[loc.lat,loc.lng]:adminCoords):(order.address?addressDirectionsUrl(order.address):null);
    cards.push(`<article class="item live-card"><div class="itemtop"><strong>Order #${1000+order.id} · ${money(order.total)}</strong><span class="pill">${escapeHtml(order.status)}</span></div><div><b>${escapeHtml(rider?.display_name||"Unassigned rider")}</b> · ${escapeHtml(rider?.phone||"No rider phone")}</div><div class="small">${escapeHtml(order.address||"No delivery address")} · ${escapeHtml(order.phone||"No customer phone")}</div><div class="small">${hasRider?escapeHtml(ageLabel(loc.updated_at)+(loc.is_sharing?"":" · sharing paused")):"Waiting for rider GPS"}${hasDestination?" · destination pinned":" · no customer GPS coordinates"}</div><div class="live-actions">${nav?`<a href="${nav}" target="_blank" rel="noopener">Navigate to customer</a>`:""}${hasRider?`<a href="${directionsUrl(loc.lat,loc.lng,adminCoords)}" target="_blank" rel="noopener">Navigate to rider</a>`:""}</div></article>`);
  }
  el("mapRiderCount").textContent=reporting;el("mapOrderCount").textContent=active.length;el("mapOfflineCount").textContent=stale;
  el("liveDeliveries").innerHTML=cards.length?cards.join(""):'<div class="item small">No assigned active deliveries. Assign a rider to a confirmed order to see it here.</div>';
  if(bounds.length&&(fit||mapFirstFit)){dispatchMap.fitBounds(bounds,{padding:[35,35],maxZoom:14});mapFirstFit=false;}
  showMessage("mapMsg",`${reporting} rider location(s) updating · ${stale} waiting, paused or stale. Last refreshed ${new Date().toLocaleTimeString()}.`,reporting?"good":"warn");
}
async function initDispatchMap(){
  if(dispatchMap)return;
  dispatchMap=initMap("dispatchMap",[5.6037,-0.1870],11);dispatchLayer=L.layerGroup().addTo(dispatchMap);
  el("locateAdmin").addEventListener("click",()=>{
    if(!navigator.geolocation){showMessage("mapMsg","This browser does not support location.","warn");return;}
    el("locateAdmin").disabled=true;
    navigator.geolocation.getCurrentPosition(pos=>{
      adminCoords=[pos.coords.latitude,pos.coords.longitude];dispatchMap.setView(adminCoords,14);el("locateAdmin").disabled=false;
      showMessage("mapMsg","Your location is used only as the navigation starting point on this device.","good");
      refreshLiveMap(true).catch(e=>showMessage("mapMsg",e.message,"bad"));
    },err=>{el("locateAdmin").disabled=false;showMessage("mapMsg",`Could not access your location: ${err.message}. You can still navigate from a rider's live position.`,"warn");},{enableHighAccuracy:true,timeout:12000,maximumAge:60000});
  });
  await refreshLiveMap(true);
  mapChannel=db.channel("admin-live-delivery-map")
    .on("postgres_changes",{event:"*",schema:"public",table:"rider_locations"},()=>refreshLiveMap().catch(e=>showMessage("mapMsg",e.message,"bad")))
    .on("postgres_changes",{event:"*",schema:"public",table:"delivery_assignments"},async()=>{await loadDispatch();await refreshLiveMap(true);})
    .on("postgres_changes",{event:"*",schema:"public",table:"orders"},async()=>{await loadDispatch();})
    .subscribe();
  mapRefreshTimer=setInterval(()=>refreshLiveMap().catch(e=>showMessage("mapMsg",e.message,"bad")),10000);
}
el("loginForm").addEventListener("submit",async e=>{e.preventDefault();try{await signInForm(el("email").value.trim(),el("password").value);await bootDispatch();}catch(err){showMessage("loginMsg",err.message,"bad");}});
el("riderForm").addEventListener("submit",async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const {data,error}=await db.rpc("register_delivery_rider",{p_email:el("riderEmail").value.trim(),p_display_name:el("riderName").value.trim(),p_phone:el("riderPhone").value.trim()||null});if(error)throw error;showMessage("riderMsg","Rider registered. User ID: "+data,"good");el("riderForm").reset();await loadDispatch();}catch(err){showMessage("riderMsg",err.message,"bad");}finally{b.disabled=false;}});
el("orders").addEventListener("click",async e=>{
  const assign=e.target.closest("[data-assign]"),unassign=e.target.closest("[data-unassign]");
  if(assign){const id=Number(assign.dataset.assign),select=el("orders").querySelector(`[data-order="${id}"]`),riderId=select.value;if(!riderId){showMessage("ordersMsg","Choose a rider first.","warn");return;}assign.disabled=true;
    const {error}=await db.from("delivery_assignments").upsert({order_id:id,rider_id:riderId,assigned_by:adminUser.id},{onConflict:"order_id"});
    if(error){showMessage("ordersMsg",error.message,"bad");assign.disabled=false;return;}showMessage("ordersMsg","Assignment saved for order #"+(1000+id)+".","good");await loadDispatch();}
  if(unassign){const id=Number(unassign.dataset.unassign);unassign.disabled=true;const {error}=await db.from("delivery_assignments").delete().eq("order_id",id);if(error){showMessage("ordersMsg",error.message,"bad");unassign.disabled=false;return;}showMessage("ordersMsg","Rider unassigned.","good");await loadDispatch();}
});
bootDispatch().catch(e=>showMessage("loginMsg",e.message,"bad"));
window.addEventListener("beforeunload",()=>{if(mapRefreshTimer)clearInterval(mapRefreshTimer);if(mapChannel)db.removeChannel(mapChannel);});
