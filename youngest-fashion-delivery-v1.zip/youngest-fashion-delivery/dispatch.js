let adminUser=null,riders=[],orders=[],assignments=[];
async function bootDispatch(){
  const session=await requireSession();if(!session){el("loginPanel").classList.remove("hidden");return;}
  adminUser=session.user;
  const {data:p,error}=await db.from("profiles").select("role").eq("id",adminUser.id).single();
  if(error||!p||!["admin","super_admin"].includes(p.role)){await db.auth.signOut();el("loginPanel").classList.remove("hidden");showMessage("loginMsg","This account does not have administrator access.","bad");return;}
  el("loginPanel").classList.add("hidden");el("appPanel").classList.remove("hidden");await loadDispatch();
}
async function loadDispatch(){
  const [rr,oo,aa]=await Promise.all([
    db.from("delivery_riders").select("user_id,display_name,phone,is_active").order("created_at",{ascending:false}),
    db.from("orders").select("id,status,total,address,phone,created_at").in("status",["confirmed","on the way"]).order("created_at",{ascending:false}),
    db.from("delivery_assignments").select("order_id,rider_id,assigned_at")
  ]);
  for(const x of [rr,oo,aa])if(x.error)throw x.error;
  riders=rr.data||[];orders=oo.data||[];assignments=aa.data||[];
  renderRiders();renderOrders();
}
function renderRiders(){
  el("riders").innerHTML=riders.length?riders.map(r=>`<div class="item"><div class="itemtop"><strong>${escapeHtml(r.display_name)}</strong><span class="pill">${r.is_active?"ACTIVE":"PAUSED"}</span></div><span class="small">${escapeHtml(r.phone||"No phone")} · ${r.user_id.slice(0,8)}…</span></div>`).join(""):'<div class="item small">No riders registered yet.</div>';
}
function renderOrders(){
  el("orders").innerHTML=orders.length?orders.map(o=>{
    const a=assignments.find(x=>x.order_id===o.id),assigned=a&&riders.find(r=>r.user_id===a.rider_id);
    return `<article class="item"><div class="itemtop"><strong>Order #${1000+o.id} · ${money(o.total)}</strong><span class="pill">${escapeHtml(o.status)}</span></div><div>${escapeHtml(o.address||"No address")}</div><div class="small">${escapeHtml(o.phone||"No phone")}</div>
    <div class="field"><label>Assign rider ${assigned?"(currently: "+escapeHtml(assigned.display_name)+")":""}</label><select data-order="${o.id}"><option value="">Choose rider…</option>${riders.filter(r=>r.is_active).map(r=>`<option value="${r.user_id}" ${a?.rider_id===r.user_id?"selected":""}>${escapeHtml(r.display_name)}</option>`).join("")}</select></div>
    <div class="btnrow"><button class="btn" data-assign="${o.id}">Save assignment</button>${a?`<button class="btn secondary" data-unassign="${o.id}">Unassign</button>`:""}</div></article>`;
  }).join(""):'<div class="item small">No confirmed or on-the-way orders waiting for dispatch.</div>';
}
el("loginForm").addEventListener("submit",async e=>{e.preventDefault();try{await signInForm(el("email").value.trim(),el("password").value);await bootDispatch();}catch(err){showMessage("loginMsg",err.message,"bad");}});
el("riderForm").addEventListener("submit",async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const {data,error}=await db.rpc("register_delivery_rider",{p_email:el("riderEmail").value.trim(),p_display_name:el("riderName").value.trim(),p_phone:el("riderPhone").value.trim()||null});if(error)throw error;showMessage("riderMsg","Rider registered. User ID: "+data,"good");el("riderForm").reset();await loadDispatch();}catch(err){showMessage("riderMsg",err.message,"bad");}finally{b.disabled=false;}});
el("orders").addEventListener("click",async e=>{
  const assign=e.target.closest("[data-assign]"),unassign=e.target.closest("[data-unassign]");
  if(assign){const id=Number(assign.dataset.assign),select=el("orders").querySelector(`[data-order="${id}"]`),riderId=select.value;if(!riderId){showMessage("ordersMsg","Choose a rider first.","warn");return;}assign.disabled=true;
    const {error}=await db.from("delivery_assignments").upsert({order_id:id,rider_id:riderId,assigned_by:adminUser.id},{onConflict:"order_id"});
    if(error){showMessage("ordersMsg",error.message,"bad");assign.disabled=false;return;}showMessage("ordersMsg","Assignment saved for order #"+(1000+id)+".","good");await loadDispatch();}
  if(unassign){const id=Number(unassign.dataset.unassign);unassign.disabled=true;const {error}=await db.from("delivery_assignments").delete().eq("order_id",id);if(error){showMessage("ordersMsg",error.message,"bad");unassign.disabled=false;return;}showMessage("ordersMsg","Rider unassigned.","good");await loadDispatch();}
});
bootDispatch().catch(e=>showMessage("loginMsg",e.message,"bad"));
